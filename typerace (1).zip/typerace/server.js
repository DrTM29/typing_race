const express = require('express');
const http = require('http');
const WebSocket = require('ws');
const { v4: uuidv4 } = require('uuid');
const path = require('path');

const app = express();
const server = http.createServer(app);
const wss = new WebSocket.Server({ server });

app.use(express.static(path.join(__dirname, 'public')));

// In-memory state
const rooms = new Map(); // roomId -> room
const allTimeScores = []; // global leaderboard

const PASSAGES = [
  { id: 'classic', name: 'Classic', text: 'The quick brown fox jumps over the lazy dog. Pack my box with five dozen liquor jugs. How vexingly quick daft zebras jump and frolic.' },
  { id: 'science', name: 'Science', text: 'The speed of light in a vacuum is approximately 299,792,458 metres per second. Nothing with mass can reach or exceed this fundamental cosmic speed limit.' },
  { id: 'technology', name: 'Technology', text: 'Artificial intelligence is the simulation of human intelligence processes by machines. These processes include learning, reasoning, and self-correction to solve complex problems.' },
  { id: 'literature', name: 'Literature', text: 'It was the best of times, it was the worst of times, it was the age of wisdom, it was the age of foolishness, it was the epoch of belief, it was the epoch of incredulity.' },
  { id: 'nature', name: 'Nature', text: 'The mountains rise above the clouds, their peaks dusted with snow even in summer. Rivers carve their way through ancient valleys, nourishing forests teeming with life.' },
];

const AVATARS = ['🐉','🦊','🐺','👻','🤖','🦁','🐯','🐻','🦋','🐝','🦅','🐬','🦄','🐸','🐙','🦖','🐠','🦉','🐺','🦊'];

function createRoom(hostId, hostName, hostStudentId, settings = {}) {
  const roomId = uuidv4().slice(0, 8).toUpperCase();
  const room = {
    id: roomId,
    hostId,
    settings: {
      difficulty: settings.difficulty || 'medium',
      maxPlayers: settings.maxPlayers || 5,
      startDelay: settings.startDelay || 10,
      passageId: settings.passageId || 'classic',
      customText: settings.customText || '',
    },
    players: new Map(), // socketId -> player
    chat: [{ system: true, text: `${hostName} created the lobby.`, time: Date.now() }],
    phase: 'lobby', // lobby | countdown | racing | results
    startTime: null,
    raceResults: [],
    countdownTimer: null,
  };
  rooms.set(roomId, room);
  return room;
}

function getPassageText(room) {
  if (room.settings.passageId === 'custom') {
    return room.settings.customText && room.settings.customText.trim().length >= 10
      ? room.settings.customText.trim()
      : 'No custom text was entered. Please go back and add a passage in Settings.';
  }
  // difficulty=random: pick a random built-in
  if (room.settings.difficulty === 'random') {
    return PASSAGES[Math.floor(Math.random() * PASSAGES.length)].text;
  }
  const p = PASSAGES.find(p => p.id === room.settings.passageId);
  return p ? p.text : PASSAGES[0].text;
}

function broadcast(room, msg, excludeId = null) {
  const data = JSON.stringify(msg);
  room.players.forEach((player, sid) => {
    if (sid !== excludeId && player.ws && player.ws.readyState === WebSocket.OPEN) {
      player.ws.send(data);
    }
  });
}

function broadcastAll(room, msg) {
  broadcast(room, msg);
}

function sendTo(ws, msg) {
  if (ws && ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify(msg));
}

function roomState(room) {
  return {
    type: 'room_state',
    room: {
      id: room.id,
      hostId: room.hostId,
      settings: room.settings,
      players: Array.from(room.players.values()).map(p => ({
        id: p.id, name: p.name, studentId: p.studentId,
        avatar: p.avatar, ready: p.ready, progress: p.progress,
        wpm: p.wpm, finished: p.finished, finishTime: p.finishTime, place: p.place,
      })),
      chat: room.chat.slice(-50),
      phase: room.phase,
      passage: room.phase !== 'lobby' ? getPassageText(room) : null,
      startTime: room.startTime,
      raceResults: room.raceResults,
    }
  };
}

wss.on('connection', (ws) => {
  ws.id = uuidv4();

  ws.on('message', (raw) => {
    let msg;
    try { msg = JSON.parse(raw); } catch { return; }

    switch (msg.type) {

      case 'create_room': {
        const room = createRoom(ws.id, msg.name, msg.studentId, msg.settings || {});
        const player = {
          id: ws.id, ws, name: msg.name, studentId: msg.studentId,
          avatar: msg.avatar || '👻', ready: true,
          progress: 0, wpm: 0, finished: false, finishTime: null, place: null,
        };
        room.players.set(ws.id, player);
        ws.roomId = room.id;
        sendTo(ws, { type: 'joined', roomId: room.id, playerId: ws.id });
        sendTo(ws, roomState(room));
        break;
      }

      case 'join_room': {
        const room = rooms.get(msg.roomId);
        if (!room) { sendTo(ws, { type: 'error', text: 'Room not found.' }); return; }
        if (room.phase !== 'lobby') { sendTo(ws, { type: 'error', text: 'Race already in progress.' }); return; }
        if (room.players.size >= room.settings.maxPlayers) { sendTo(ws, { type: 'error', text: 'Room is full.' }); return; }
        const existing = Array.from(room.players.values()).find(p => p.studentId === msg.studentId);
        if (existing) { sendTo(ws, { type: 'error', text: 'Student ID already in this room.' }); return; }

        const player = {
          id: ws.id, ws, name: msg.name, studentId: msg.studentId,
          avatar: msg.avatar || '👻', ready: false,
          progress: 0, wpm: 0, finished: false, finishTime: null, place: null,
        };
        room.players.set(ws.id, player);
        ws.roomId = room.id;
        room.chat.push({ system: true, text: `${msg.name} joined the lobby.`, time: Date.now() });

        sendTo(ws, { type: 'joined', roomId: room.id, playerId: ws.id });
        broadcastAll(room, roomState(room));
        break;
      }

      case 'update_settings': {
        const room = rooms.get(ws.roomId);
        if (!room || room.hostId !== ws.id) return;
        Object.assign(room.settings, msg.settings);
        broadcastAll(room, roomState(room));
        break;
      }

      case 'set_ready': {
        const room = rooms.get(ws.roomId);
        if (!room) return;
        const player = room.players.get(ws.id);
        if (player) { player.ready = msg.ready; }
        broadcastAll(room, roomState(room));
        break;
      }

      case 'chat': {
        const room = rooms.get(ws.roomId);
        if (!room) return;
        const player = room.players.get(ws.id);
        const entry = { id: ws.id, name: player?.name || 'Unknown', text: msg.text.slice(0, 200), time: Date.now() };
        room.chat.push(entry);
        broadcastAll(room, { type: 'chat_message', message: entry });
        break;
      }

      case 'start_race': {
        const room = rooms.get(ws.roomId);
        if (!room || room.hostId !== ws.id || room.phase !== 'lobby') return;
        room.phase = 'countdown';
        const passage = getPassageText(room);
        broadcastAll(room, { type: 'countdown_start', passage, delay: room.settings.startDelay });
        
        let count = room.settings.startDelay;
        broadcastAll(room, { type: 'countdown_tick', count });
        room.countdownTimer = setInterval(() => {
          count--;
          broadcastAll(room, { type: 'countdown_tick', count });
          if (count <= 0) {
            clearInterval(room.countdownTimer);
            room.phase = 'racing';
            room.startTime = Date.now();
            broadcastAll(room, { type: 'race_start', startTime: room.startTime });
          }
        }, 1000);
        break;
      }

      case 'progress_update': {
        const room = rooms.get(ws.roomId);
        if (!room || room.phase !== 'racing') return;
        const player = room.players.get(ws.id);
        if (!player || player.finished) return;
        player.progress = msg.progress;
        player.wpm = msg.wpm;
        broadcast(room, { type: 'player_progress', playerId: ws.id, progress: msg.progress, wpm: msg.wpm }, ws.id);
        break;
      }

      case 'finish': {
        const room = rooms.get(ws.roomId);
        if (!room || room.phase !== 'racing') return;
        const player = room.players.get(ws.id);
        if (!player || player.finished) return;
        player.finished = true;
        player.progress = 100;
        player.finishTime = Date.now() - room.startTime;
        player.wpm = msg.wpm;
        player.accuracy = msg.accuracy;
        player.errors = msg.errors;

        // Calculate place
        const finishedCount = Array.from(room.players.values()).filter(p => p.finished).length;
        player.place = finishedCount;

        const result = {
          place: player.place, id: ws.id, name: player.name,
          studentId: player.studentId, avatar: player.avatar,
          wpm: msg.wpm, accuracy: msg.accuracy, errors: msg.errors,
          finishTime: player.finishTime,
        };
        room.raceResults.push(result);

        // Update global leaderboard
        const existing = allTimeScores.find(s => s.studentId === player.studentId);
        if (!existing || msg.wpm > existing.wpm) {
          const idx = allTimeScores.findIndex(s => s.studentId === player.studentId);
          const entry = { name: player.name, studentId: player.studentId, avatar: player.avatar, wpm: msg.wpm, accuracy: msg.accuracy, date: new Date().toLocaleDateString() };
          if (idx >= 0) allTimeScores.splice(idx, 1, entry);
          else allTimeScores.push(entry);
          allTimeScores.sort((a, b) => b.wpm - a.wpm);
        }

        broadcastAll(room, { type: 'player_finished', result, raceResults: room.raceResults });

        // Check if all finished
        const allDone = Array.from(room.players.values()).every(p => p.finished);
        if (allDone) {
          room.phase = 'results';
          broadcastAll(room, { type: 'race_over', raceResults: room.raceResults });
        }
        break;
      }

      case 'kick_player': {
        const room = rooms.get(ws.roomId);
        if (!room || room.hostId !== ws.id) return;
        const target = Array.from(room.players.values()).find(p => p.studentId === msg.studentId);
        if (target && target.id !== ws.id) {
          sendTo(target.ws, { type: 'kicked' });
          room.players.delete(target.id);
          room.chat.push({ system: true, text: `${target.name} was removed from the lobby.`, time: Date.now() });
          broadcastAll(room, roomState(room));
        }
        break;
      }

      case 'get_hiscores': {
        sendTo(ws, { type: 'hiscores', scores: allTimeScores.slice(0, 50) });
        break;
      }

      case 'export_csv': {
        const room = rooms.get(ws.roomId);
        if (!room) return;
        sendTo(ws, { type: 'csv_data', results: room.raceResults, passage: getPassageText(room) });
        break;
      }
    }
  });

  ws.on('close', () => {
    if (!ws.roomId) return;
    const room = rooms.get(ws.roomId);
    if (!room) return;
    const player = room.players.get(ws.id);
    if (player) {
      room.chat.push({ system: true, text: `${player.name} left.`, time: Date.now() });
      room.players.delete(ws.id);
    }
    if (room.players.size === 0) {
      if (room.countdownTimer) clearInterval(room.countdownTimer);
      rooms.delete(room.id);
    } else {
      if (room.hostId === ws.id) {
        const next = room.players.values().next().value;
        if (next) {
          room.hostId = next.id;
          room.chat.push({ system: true, text: `${next.name} is now the host.`, time: Date.now() });
        }
      }
      broadcastAll(room, roomState(room));
    }
  });
});

// REST endpoint for hiscores (for sharing)
app.get('/api/hiscores', (req, res) => {
  res.json(allTimeScores.slice(0, 50));
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => console.log(`TypeRace server running on port ${PORT}`));
