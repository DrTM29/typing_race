# TypeRace — Multiplayer Typing Race

A real-time multiplayer typing race app for classrooms. Students join by entering their Student ID and compete live.

## Features
- **Create/Join rooms** with a shareable link or room code
- **Live race** with real-time progress bars for all players
- **Settings** (difficulty, max players, start delay, custom passage, kick players)
- **Avatar picker** with 20 emoji avatars, paged
- **Live chat** in lobby, during race, and in results
- **Podium & results** with place, WPM, accuracy, errors, time
- **Global hiscores** leaderboard (best WPM per student ID)
- **Export CSV** of race results
- **Auto host transfer** if host disconnects

## Quick Start (Local)

```bash
npm install
npm start
# Open http://localhost:3000
```

## Deploy to Railway (Free, instant public URL)

1. Create account at [railway.app](https://railway.app)
2. New Project → Deploy from GitHub (or drag-and-drop folder)
3. Set start command: `npm start`
4. Railway gives you a public URL like `https://typerace-xxx.railway.app`
5. Share the URL with students!

## Deploy to Render (Free)

1. Push to GitHub
2. Go to [render.com](https://render.com) → New Web Service
3. Connect your repo
4. Build command: `npm install`
5. Start command: `node server.js`
6. Deploy — you get a public URL

## Deploy to Fly.io

```bash
npm install -g flyctl
fly launch
fly deploy
```

## Deploy to Heroku

```bash
heroku create your-typerace-app
git push heroku main
heroku open
```

## How It Works

- **WebSocket server** (ws) handles all real-time multiplayer communication
- **Express** serves the static frontend
- Rooms are identified by 8-character codes (e.g. `A1B2C3D4`)
- Joining: students go to the URL, enter ID + name + room code
- Or use the direct link: `https://yourapp.com?room=A1B2C3D4`

## How to Use in a Classroom

1. Teacher clicks **Create Room**, sets passage and difficulty
2. Teacher shares the URL: `https://yourapp.com?room=XXXXXXXX`
3. Students open the link, enter their Student ID and name
4. Teacher clicks **START GAME** when everyone is ready
5. After the race, teacher clicks **Export CSV** to download results

## Tech Stack
- Node.js + Express + ws (WebSocket)
- Vanilla HTML/CSS/JS frontend (no build step)
- All state in-memory (resets on server restart)
